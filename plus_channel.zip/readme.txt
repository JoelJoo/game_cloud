Title: Plus Channel Regular
Type: TrueType font file
Company: Plus Channel
File version: 2.1
Font embeddability: Installable
Authors: Plus Channel
Copyright: © Plus Channel
Legal trademarks: This font is a trademark of Plus Channel
File description: This font is created by Plus Channel
License description: Free for personal use

Inspired by the current Plus Channel logo

Free for personal use to sent your email: pluschannelalternate83@gmail.com

You need to get this font for a website: https://pluschannelalternate83.blogspot.com/